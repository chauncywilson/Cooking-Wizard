import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.io.*;
import java.util.ArrayList;

/**
 * @author Chauncy Wilson
 * @version 1.0.0
 * This Program is used as a tool by chefs and bakers for easy use to convert and multiply the recipe
 * Creates and manipulates the GUI
 */
public class Display extends Application implements Serializable {
    TextArea textArea = new TextArea();
    int mode = 0;
    ArrayList<Double> amounts = new ArrayList<>();
    ArrayList<String> types = new ArrayList<>();
    ArrayList<String> notes = new ArrayList<>();

    /**
     * @param primaryStage A stage variable, used to create the display. Needs Javafx to run
     */
    @Override
    public void start(Stage primaryStage) {

        GridPane pane = new GridPane();

        HBox unit = makeUnitHBox();
        HBox conversions = makeTopHBox();

        setTextArea();

        Text helper = new Text("1/2 = 0.5    1/3 = 0.33    2/3 = 0.66" +
                "    1/4 = 0.25   3/4 = 0.75    1/8 = 0.125");

        pane.setPadding(new Insets(15));
        pane.add(conversions, 1, 0);
        pane.add(unit, 1, 1);
        pane.add(textArea, 1, 2);
        pane.add(helper, 1, 3);
        pane.setAlignment(Pos.TOP_CENTER);

        Scene scene = new Scene(pane, 500, 300);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Cooking Wizard");
        primaryStage.show();
    }

    /**
     * Creates the text box where the recipe resides
     */
    private void setTextArea() {
        textArea.setMaxSize(400, 400);
        textArea.setWrapText(true);
        textArea.editableProperty().setValue(false);
        textArea.scrollTopProperty().set(0);
    }

    /**
     * @return Hbox containing the radio buttons and action methods to multiply the recipe by
     * either 1/2, double, triple and no change
     */
    private HBox makeTopHBox() {
        RadioButton rbDouble = new RadioButton("Double");
        RadioButton rbTriple = new RadioButton("Triple");
        RadioButton rbHalf = new RadioButton("Half");
        RadioButton rbNormal = new RadioButton("Normal");

        rbHalf.setOnAction(event -> {mode = 1; modifyRecipe();});
        rbDouble.setOnAction(event -> {mode = 2; modifyRecipe();});
        rbTriple.setOnAction(event -> {mode = 3; modifyRecipe();});
        rbNormal.setOnAction(event -> {mode = 0; modifyRecipe();});

        ToggleGroup group = new ToggleGroup();
        group.getToggles().addAll(rbHalf, rbNormal, rbDouble, rbTriple);

        HBox hBox = new HBox();
        hBox.getChildren().addAll(rbHalf, rbNormal, rbDouble, rbTriple);
        hBox.setSpacing(20);
        hBox.alignmentProperty().setValue(Pos.CENTER);
        return hBox;
    }

    /**
     * @return The main interface of the GUI that is interacted by the user as well as the
     * action button to add to the text area
     */
    private HBox makeUnitHBox() {
        TextField amount = new TextField(".5");
        ComboBox<String> type = new ComboBox<>();
        TextField note = new TextField("flour");
        Button addButton = new Button("Add");

        addButton.setOnAction(event -> {
                String amountPlaceHolder = amount.getText();
                double newAmount = Double.parseDouble(amountPlaceHolder);

                String newType = type.getValue();

                String newNote = note.getText();

                writeTextArea(newAmount, newType, newNote);
        });

        setComboBox(type);

        amount.editableProperty().setValue(true);
        note.editableProperty().setValue(true);

        amount.setMaxSize(50, 15);
        amount.alignmentProperty().setValue(Pos.CENTER);

        HBox hBox = new HBox(amount, type, note, addButton);
        hBox.alignmentProperty().setValue(Pos.TOP_CENTER);
        hBox.setSpacing(10);
        hBox.setPadding(new Insets(7, 15, 15, 15));
        return hBox;
    }

    /**
     * @param type ComboBox String contains the valid measurements for the program
     */
    private void setComboBox(ComboBox<String> type) {
        type.getItems().addAll("", "tsp", "tbsp", "liquid cup", "cup", "oz", "pt", "qt", "gal");
        type.setValue("cup");
    }

    /**
     * @param amount the monetary input from the user to dignify the quantity
     * @param type one of the valid inputs from the ComboBox turned string
     * @param note is used for the users' convenience to know which piece of the recipe is being manipulated
     *
     * This method also adds these values into 3 different ArrayList classes to store as the master list
     */
    private void writeTextArea(double amount, String type, String note) {
        if (type.equals("")) {
            textArea.appendText(amount + " ");
            textArea.appendText(note + "\n");
        } else {
            textArea.appendText(amount + " ");
            textArea.appendText(type + " ");
            textArea.appendText(note + "\n");
        }

        amounts.add(amount);
        types.add(type);
        notes.add(note);
    }


    /**
     * takes the values from the ArrayLists and the radio buttons to modify the text field to update the recipe
     * this method also calls the methods from the ConversionCalculator class
     */
    private void modifyRecipe() {
        ConversionCalculator calculator = new ConversionCalculator();

        textArea.clear();

        //obtain information from the master arrays
        for (int i = 0; i < amounts.size(); i++) {
            double amount = amounts.get(i);
            String type = types.get(i);

            //calls the math to change the amount
            double newAmount = calculator.applyMode(mode, amount);

            //convert to a simpler unit if necessary
            if (mode != 0) {
            switch (type) {
                case "tsp":
                    if (newAmount >= 3) {
                        newAmount = calculator.toTbsp(newAmount, type);
                        type = "tbsp";
                    }
                    break;

                case "tbsp":
                    if (newAmount >= 4) {
                        newAmount = calculator.toCup(newAmount, type);
                        type = "cup";
                    } else if (newAmount < 1 && newAmount != 0.5) {
                        newAmount = calculator.toTsp(newAmount, type);
                        type = "tsp";
                    }
                    break;

                case "cup":
                    if (newAmount < 0.25) {
                        newAmount = calculator.toTbsp(newAmount, type);
                        type = "tbsp";
                    }
                    break;

                case "liquid cup":
                    if (newAmount >= 2) {
                        newAmount = calculator.toPt(newAmount, type);
                        type = "pt";
                        if (newAmount >= 2) {
                            newAmount = calculator.toQt(newAmount, type);
                            type = "qt";
                            if (newAmount >= 4) {
                                newAmount = calculator.toGallon(newAmount, type);
                                type  = "gal";
                            }
                        }
                    } else if (newAmount <= 0.125) {
                        newAmount = calculator.toOz(newAmount, type);
                        type = "oz";
                    }
                    break;

                case "oz":
                    if (newAmount >= 8) {
                        newAmount = calculator.toLCup(newAmount, type);
                        type = "liquid cup";
                    }
                    break;

                case "pt":
                    if (newAmount >= 2) {
                        newAmount = calculator.toQt(newAmount, type);
                        type = "qt";
                        if (newAmount >= 4) {
                            newAmount = calculator.toGallon(newAmount, type);
                            type = "gal";
                        }
                    } else if (newAmount <= 0.5) {
                        newAmount = calculator.toLCup(newAmount, type);
                        type = "Liquid cup";
                    }
                    break;

                case "qt":
                    if (newAmount >= 4) {
                        newAmount = calculator.toGallon(newAmount, type);
                        type = "gal";
                    } else if (newAmount <= 0.5) {
                        newAmount = calculator.toPt(newAmount, type);
                        type = "pt";
                    }
                    break;

                case "gal":
                    if (newAmount <= 0.5) {
                        newAmount = calculator.toQt(newAmount, type);
                        type = "qt";
                    }
                    break;
                }
            }

            if (type.equals("")) {
                textArea.appendText(newAmount + " ");
                textArea.appendText(notes.get(i) + "\n");
            } else {
                textArea.appendText(newAmount + " ");
                textArea.appendText("" + type + " ");
                textArea.appendText(notes.get(i) + "\n");
            }
        }
    }

    //Only required for compilation
    public static void main(String[] args) {
        launch();
    }
}