import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ConversionCalculatorTest {
    ConversionCalculator conversionCalculator = new ConversionCalculator();

    @Test
    void toCup() {
        assertEquals(0.5, conversionCalculator.toCup(8, "tbsp"));
        assertEquals(1, conversionCalculator.toCup(16, "tbsp"));
    }

    @Test
    void toTbsp() {
        assertEquals(4, conversionCalculator.toTbsp(.25, "cup"));
        assertEquals(2, conversionCalculator.toTbsp(6, "tsp"));
    }

    @Test
    void toTsp() {
        assertEquals(1, conversionCalculator.toTsp(.33, "tbsp"));
    }

    @Test
    void toOz() {
        assertEquals(8, conversionCalculator.toOz(1, "liquid cup"));
    }

    @Test
    void toLCup() {
        assertEquals(1, conversionCalculator.toLCup(8, "oz"));
        assertEquals(.5, conversionCalculator.toLCup(.25, "pt"));
    }

    @Test
    void toPt() {
        assertEquals(4, conversionCalculator.toPt(8, "liquid cup"));
        assertEquals(4, conversionCalculator.toPt(2,"qt"));
    }

    @Test
    void toQt() {
        assertEquals(3, conversionCalculator.toQt(6, "pt"));
        assertEquals(4, conversionCalculator.toQt(1, "gal"));
    }

    @Test
    void toGallon() {
        assertEquals(1, conversionCalculator.toGallon(4, "qt"));
    }

    @Test
    void applyMode() {
        assertEquals(2, conversionCalculator.applyMode(1, 4));
        assertEquals(2, conversionCalculator.applyMode(2, 1));
        assertEquals(6, conversionCalculator.applyMode(3, 2));
    }
}