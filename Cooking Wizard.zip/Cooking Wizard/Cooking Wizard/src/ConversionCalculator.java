/**
 * This class is where all calculations in this program take place
 * the new variable for type is not changed inside this program and must be updated outside the class
 */
public class ConversionCalculator {
    public static void main(String[] args) {
    }

    /**
     * no arg constructor
     */
    ConversionCalculator() {
    }

    /**
     * takes "tbsp" and converts the quantity to amount
     * @param amount the numeric quantity of the recipe portion
     * @param type the unit of measurement, must be "tbsp" or it will not change the value
     * @return the new amount as a "cup"
     */
    public double toCup(double amount, String type) {
        if (type.equals("tbsp")) {
            amount /= 16;
        }
        return amount;
    }

    /**
     * takes "cup" or "tsp" and converts the quantity to amount
     * @param amount the numeric quantity of the recipe portion
     * @param type the unit of measurement, must be "cup" or "tsp" or it will not change the value
     * @return the new amount as a "tbsp"
     */
    public double toTbsp(double amount, String type) {
        if (type.equals("cup")) {
            amount *= 16;
        } else if (type.equals("tsp")) {
            amount /= 3;
        }

        int intAmount = (int) amount;
        if (amount - intAmount == .99) {
            amount = intAmount;
            amount++;
        }
        if (amount - intAmount > .65 && amount - intAmount < .67) {
            amount = intAmount + .66;
        }
        if (amount - intAmount > .32 && amount - intAmount < .34) {
            amount = intAmount + .33;
        }
        return amount;
    }

    /**
     * takes "cup" or "tsp" and converts the quantity to amount
     * @param amount the numeric quantity of the recipe portion
     * @param type the unit of measurement, must be "tbsp" or it will not change the value
     * @return the new amount as a "tsp"
     */
    public double toTsp(double amount, String type) {
        if (type.equals("tbsp")) {
            amount *= 3;
        }

        int intAmount = (int) amount;
        if (amount - intAmount == .99) {
            amount = intAmount;
            amount++;
        }
        if (amount - intAmount > .65 && amount - intAmount < .67) {
            amount = intAmount + .66;
        }
        if (amount - intAmount == .3333333333333333) {
            amount = intAmount + .33;
        }

        return amount;
    }

    /**
     * takes "liquid cup" and converts the quantity to amount
     * @param amount the numeric quantity of the recipe portion
     * @param type the unit of measurement, must be "liquid cup" or it will not change the value
     * @return the new amount as an "oz"
     */
    public double toOz(double amount, String type) {
        if (type.equals("liquid cup")) {
            amount *= 8;
        }
        return amount;
    }

    /**
     * takes "oz" or "pt" and converts the quantity to amount
     * @param amount the numeric quantity of the recipe portion
     * @param type the unit of measurement, must be "oz" or "pt" or it will not change the value
     * @return the new amount as "liquid cup"
     */
    public double toLCup(double amount, String type) {
        if (type.equals("oz")) {
            amount /= 8;
        } else if (type.equals("pt")) {
            amount *= 2;
        }
        return amount;
    }

    public double toPt(double amount, String type) {
        if (type.equals("liquid cup")) {
            amount /= 2;
        } else if (type.equals("qt")) {
            amount *= 2;
        }
        return amount;
    }

    /**
     * takes "pt" or "gal" and converts the quantity to amount
     * @param amount the numeric quantity of the recipe portion
     * @param type the unit of measurement, must be "pt" or "gal" or it will not change the value
     * @return the new amount as a "qt"
     */
    public double toQt(double amount, String type) {
        if (type.equals("pt")) {
            amount /= 2;
        } else if (type.equals("gal")) {
            amount *= 4;
        }
        return amount;
    }

    /**
     * takes "qt" and converts the quantity to amount
     * @param amount the numeric quantity of the recipe portion
     * @param type the unit of measurement, must be "qt" or it will not change the value
     * @return the new amount as a "gal"
     */
    public double toGallon(double amount, String type) {
        if (type.equals("qt")) {
            amount /= 4;
        }
        return amount;
    }


    /**
     * @param mode takes an int to know whether to half, double, or triple the amount.
     *            1 = halved, 2 = doubled, 3 = tripled
     * @param amount the numeric quantity of the recipe portion
     * @return double amount as the new value after the recipe has been altered
     */
    public double applyMode(int mode, double amount) {
        switch (mode) {
            case 1:
                if (amount == 1) {
                    amount -= 0.5;
                } else {
                    amount *= 0.5;
                }
                break;

            case 2:
                if (amount == 1) {
                    amount += 1;
                } else {
                    amount *= 2;
                }
                break;

            case 3:
                if (amount == 1) {
                    amount += 2;
                } else {
                    amount *= 3;
                }
                break;
            }
        return amount;
    }
}